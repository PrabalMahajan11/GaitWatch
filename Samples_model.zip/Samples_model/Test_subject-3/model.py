import numpy as np
import csv
import pandas as pd

data = pd.read_csv('output.csv',sep=',')
# print(data.columns)
print(data.head)
from sklearn.model_selection import train_test_split

X = data.iloc[:,:-1]
y = data.iloc[:,-1:]
# print(X.head)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

